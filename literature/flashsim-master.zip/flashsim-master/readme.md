# Extended FlashSim

This project extends FlashSim with BAST, FAST and DFTL FTLs. 

Please reference if you use for your research.

Bibtex

    @article{extendedflashsim,
    Author = {Matias Bj{\o}rling},
    Title = {Extended FlashSim},
    Url = {https://github.com/MatiasBjorling/flashsim},
    Year = 2011}

The FTL algorihms are implemented on top of the Flash based SSD simulator implementation created by Brendan Tauras btauras, Youngjae Kim, Aayush Gupta at Pennsylvania State University.




